use crate::prelude::*;

#[derive(Component)]
pub struct Player;